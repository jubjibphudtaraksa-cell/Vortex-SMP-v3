package net.vortexsmp.scoreboard;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Vortex SMP - sidebar scoreboard แยกของแต่ละคน
 *
 *  Vortex SMP        (ม่วง)
 *  <ชื่อผู้เล่น>       (ฟ้า)
 *  Playtime 2h 15m   (เหลือง/ขาว)
 *  Kill/Dead 3(6)    (เขียว/แดง)
 */
public final class VortexScoreboard extends JavaPlugin implements Listener {

    private static final TextColor PURPLE = TextColor.color(0xA020F0);
    private static final String[] ENTRIES = {"§0", "§1", "§2"};

    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);

        for (Player player : Bukkit.getOnlinePlayers()) {
            createBoard(player);
        }

        // อัปเดตทุก 1 วินาที (เวลาเล่น, kill, dead)
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                updateBoard(player);
            }
        }, 20L, 20L);
    }

    @Override
    public void onDisable() {
        Scoreboard main = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.setScoreboard(main);
        }
        boards.clear();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        createBoard(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        boards.remove(event.getPlayer().getUniqueId());
    }

    private void createBoard(Player player) {
        // scoreboard ใหม่ของผู้เล่นแต่ละคน -> เห็นแค่ของตัวเอง
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();

        Objective objective = board.registerNewObjective(
                "vortex",
                Criteria.DUMMY,
                Component.text("Vortex SMP", PURPLE, TextDecoration.BOLD)
        );
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        // ซ่อนเลขสีแดงด้านขวา
        objective.numberFormat(NumberFormat.blank());

        // 3 บรรทัด เรียงจากบนลงล่าง (score มาก -> น้อย)
        objective.getScore(ENTRIES[0]).setScore(3);
        objective.getScore(ENTRIES[1]).setScore(2);
        objective.getScore(ENTRIES[2]).setScore(1);

        boards.put(player.getUniqueId(), board);
        player.setScoreboard(board);
        updateBoard(player);
    }

    private void updateBoard(Player player) {
        Scoreboard board = boards.get(player.getUniqueId());
        if (board == null) {
            return;
        }
        Objective objective = board.getObjective("vortex");
        if (objective == null) {
            return;
        }

        // บรรทัด 1: ชื่อผู้เล่น
        Component nameLine = Component.text(player.getName(), NamedTextColor.AQUA, TextDecoration.BOLD);

        // บรรทัด 2: เวลาเล่น
        long ticks = player.getStatistic(Statistic.PLAY_ONE_MINUTE);
        Component timeLine = Component.text("Playtime ", NamedTextColor.YELLOW)
                .append(Component.text(formatTime(ticks / 20L), NamedTextColor.WHITE));

        // บรรทัด 3: Kill/Dead  เช่น 3(6)
        int kills = player.getStatistic(Statistic.PLAYER_KILLS);
        int deaths = player.getStatistic(Statistic.DEATHS);
        Component kdLine = Component.text("Kill/Dead ", NamedTextColor.GOLD)
                .append(Component.text(kills, NamedTextColor.GREEN))
                .append(Component.text("(", NamedTextColor.GRAY))
                .append(Component.text(deaths, NamedTextColor.RED))
                .append(Component.text(")", NamedTextColor.GRAY));

        objective.getScore(ENTRIES[0]).customName(nameLine);
        objective.getScore(ENTRIES[1]).customName(timeLine);
        objective.getScore(ENTRIES[2]).customName(kdLine);
    }

    private static String formatTime(long totalSeconds) {
        long days = totalSeconds / 86400;
        long hours = (totalSeconds % 86400) / 3600;
        long minutes = (totalSeconds % 3600) / 60;

        if (days > 0) {
            return days + "d " + hours + "h " + minutes + "m";
        }
        return hours + "h " + minutes + "m";
    }
}
